
package gestortickets;

public class Persona {
    
    private String nombre;
    private String correo;
    private String usuario;
    private String contraseña;
    private String rol;

    public Persona(String nombre, String correo, String usuario, String contraseña, String rol) {
        this.nombre = nombre;
        this.correo = correo;
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.rol = rol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
    
    public void gestionarTickets (){
        
    }
    
    public void verSulicitudesPendientes (){
        
    }
    
    public void agregarNotaTicket (){
        
    }
    
    public void modEstadoTicket (){
        
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", correo=" + correo + ", usuario=" + usuario + ", contrase\u00f1a=" + contraseña + ", rol=" + rol + '}';
    }
    
}
