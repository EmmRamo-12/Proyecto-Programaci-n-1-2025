
package gestortickets;

public class FlujoDeTrabajoTickets {
    
    private String nombreFlujo;
    private String estados;
    private String transicionesPermitidas;
    private String reglasDeTransicion;
    private String accionesAutomaticas;

    public FlujoDeTrabajoTickets(String nombreFlujo, String estados, String transicionesPermitidas, String reglasDeTransicion, String accionesAutomaticas) {
        this.nombreFlujo = nombreFlujo;
        this.estados = estados;
        this.transicionesPermitidas = transicionesPermitidas;
        this.reglasDeTransicion = reglasDeTransicion;
        this.accionesAutomaticas = accionesAutomaticas;
    }
    
    public String getNombreFlujo() {
        return nombreFlujo;
    }

    public void setNombreFlujo(String nombreFlujo) {
        this.nombreFlujo = nombreFlujo;
    }

    public String getEstados() {
        return estados;
    }

    public void setEstados(String estados) {
        this.estados = estados;
    }

    public String getTransicionesPermitidas() {
        return transicionesPermitidas;
    }

    public void setTransicionesPermitidas(String transicionesPermitidas) {
        this.transicionesPermitidas = transicionesPermitidas;
    }

    public String getReglasDeTransicion() {
        return reglasDeTransicion;
    }

    public void setReglasDeTransicion(String reglasDeTransicion) {
        this.reglasDeTransicion = reglasDeTransicion;
    }

    public String getAccionesAutomaticas() {
        return accionesAutomaticas;
    }

    public void setAccionesAutomaticas(String accionesAutomaticas) {
        this.accionesAutomaticas = accionesAutomaticas;
    }

    @Override
    public String toString() {
        return "FlujoDeTrabajoTickets{" + "nombreFlujo=" + nombreFlujo + ", estados=" + estados + ", transicionesPermitidas=" + transicionesPermitidas + ", reglasDeTransicion=" + reglasDeTransicion + ", accionesAutomaticas=" + accionesAutomaticas + '}';
    }
    
    
    
}
