
package gestortickets;


public class Tecnico extends Persona {
    
    private String departamento;

    public Tecnico(String nombre, String correo, String usuario, String contraseña, String rol, String departamento) {
        super(nombre, correo, usuario, contraseña, rol);
        this.departamento = departamento;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public void modEstadoTicket() {
        
    } 
}
