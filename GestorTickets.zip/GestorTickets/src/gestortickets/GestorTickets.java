
package gestortickets;

public class GestorTickets {

    public static void main(String[] args) {
        
        
        //public Tecnico(String nombre, String correo, String usuario, String contraseña, String rol, String departamento) {
        
        Tecnico tec1 = new Tecnico(
                "Carlangas Perez",
                "carlangas@gmail.com",
                "Cgomez",
                "contraseña",
                "Tecnico",
                "Soporte"
        );
        
        tec1.modEstadoTicket();
        tec1.verSulicitudesPendientes();
        
        Usuario usu1 = new Usuario (
                "Pedro Lux",
                "luxpeter@gmail0",
                "lux2345",
                "Perroazul",
                "Usuario"
        );
        
        usu1.verSulicitudesPendientes();
        
        
    }
    
}
