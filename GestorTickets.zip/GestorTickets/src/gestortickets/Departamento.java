
package gestortickets;

import java.util.ArrayList;

public class Departamento {
    
    private String nombreDepto;
    private String descripDepto;
    private ArrayList <String> tecnicosAsignados = new ArrayList <>();

    public Departamento(String nombreDepto, String descripDepto) {
        this.nombreDepto = nombreDepto;
        this.descripDepto = descripDepto;
    }
    
    public String getNombreDepto() {
        return nombreDepto;
    }

    public void setNombreDepto(String nombreDepto) {
        this.nombreDepto = nombreDepto;
    }

    public String getDescripDepto() {
        return descripDepto;
    }

    public void setDescripDepto(String descripDepto) {
        this.descripDepto = descripDepto;
    }

    public ArrayList<String> getTecnicosAsignados() {
        return tecnicosAsignados;
    }

    public void setTecnicosAsignados(ArrayList<String> tecnicosAsignados) {
        this.tecnicosAsignados = tecnicosAsignados;
    }

    @Override
    public String toString() {
        return "Departamento{" + "nombreDepto=" + nombreDepto + ", descripDepto=" + descripDepto + ", tecnicosAsignados=" + tecnicosAsignados + '}';
    }
    
    
    
    
    
}
