
package gestortickets;

public class Administrador extends Persona {

    public Administrador(String nombre, String correo, String usuario, String contraseña, String rol) {
        super(nombre, correo, usuario, contraseña, rol);
    }
    
    public void modParametrosDeSistema (){    
    }
    public void crearRol (){    
    }
    
    public void modificarRol (){    
    }
    
    public void eliminarRol (){    
    }
    
    public void crearDepto (){    
    }
    
    public void modDepto (){    
    }
    
    public void eliminarDepto (){    
    }
    
    public void registrarUsuario (){    
    }
    
    public void modUsuario (){    
    }
    
    public void eliminarUsuario (){    
    }
    
    public void crearNestadoTicket (){
    }
    
    @Override
    public void modEstadoTicket (){   
    }
    
    public void eliminarEstadoTicket (){   
    }
    
    public void crearFlujoTicket (){   
    }
    
    public void modFlujoTicket (){   
    }
    
    public void eliminarFlujoTicket (){   
    }
}
