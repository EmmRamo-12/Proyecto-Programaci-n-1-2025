
package gestortickets;

import java.util.List;


public class Empresa {
        private String nombreEmpresa;
        private String logo;
        private String zonaHoraria;
        private int tiempoDeTicket;
        private List <String> nivelPrioridadTicket;

    public Empresa(String nombreEmpresa, String logo, String zonaHoraria, int tiempoDeTicket, List<String> nivelPrioridadTicket) {
        this.nombreEmpresa = nombreEmpresa;
        this.logo = logo;
        this.zonaHoraria = zonaHoraria;
        this.tiempoDeTicket = tiempoDeTicket;
        this.nivelPrioridadTicket = nivelPrioridadTicket;
    }    
    
    
    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getZonaHoraria() {
        return zonaHoraria;
    }

    public void setZonaHoraria(String zonaHoraria) {
        this.zonaHoraria = zonaHoraria;
    }

    public int getTiempoDeTicket() {
        return tiempoDeTicket;
    }

    public void setTiempoDeTicket(int tiempoDeTicket) {
        this.tiempoDeTicket = tiempoDeTicket;
    }

    public List<String> getNivelPrioridadTicket() {
        return nivelPrioridadTicket;
    }

    public void setNivelPrioridadTicket(List<String> nivelPrioridadTicket) {
        this.nivelPrioridadTicket = nivelPrioridadTicket;
    }

    @Override
    public String toString() {
        return "Empresa{" + "nombreEmpresa=" + nombreEmpresa + ", logo=" + logo + ", zonaHoraria=" + zonaHoraria + ", tiempoDeTicket=" + tiempoDeTicket + ", nivelPrioridadTicket=" + nivelPrioridadTicket + '}';
    }
}
