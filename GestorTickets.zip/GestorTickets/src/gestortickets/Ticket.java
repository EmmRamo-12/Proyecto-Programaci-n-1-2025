
package gestortickets;


public class Ticket {
    
    private String titulo; 
    private String descripcion;
    private String deptoAsignado;
    private String nivelPrioridad;

    public Ticket(String titulo, String descripcion, String deptoAsignado, String nivelPrioridad) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.deptoAsignado = deptoAsignado;
        this.nivelPrioridad = nivelPrioridad;
    }

    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDeptoAsignado() {
        return deptoAsignado;
    }

    public void setDeptoAsignado(String deptoAsignado) {
        this.deptoAsignado = deptoAsignado;
    }

    public String getNivelPrioridad() {
        return nivelPrioridad;
    }

    public void setNivelPrioridad(String nivelPrioridad) {
        this.nivelPrioridad = nivelPrioridad;
    }
    
    

    @Override
    public String toString() {
        return "Ticket{" + "titulo=" + titulo + ", descripcion=" + descripcion + ", deptoAsignado=" + deptoAsignado + ", nivelPrioridad=" + nivelPrioridad + '}';
    }
    
}
