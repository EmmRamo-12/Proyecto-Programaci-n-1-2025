
package gestortickets;

public class GestorTickets {

    public static void main(String[] args) {
        
    }
    
}
