
package gestortickets;

public class NotaDeTicket {
    
    private int numeroTicket;
    private String contNota;

    public NotaDeTicket(int numeroTicket, String contNota) {
        this.numeroTicket = numeroTicket;
        this.contNota = contNota;
    }
    
    
    public int getNumeroTicket() {
        return numeroTicket;
    }

    public void setNumeroTicket(int numeroTicket) {
        this.numeroTicket = numeroTicket;
    }

    public String getContNota() {
        return contNota;
    }

    public void setContNota(String contNota) {
        this.contNota = contNota;
    }

    @Override
    public String toString() {
        return "NotaDeTicket{" + "numeroTicket=" + numeroTicket + ", contNota=" + contNota + '}';
    }
}
