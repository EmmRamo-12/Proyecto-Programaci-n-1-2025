
package gestortickets;


public class Usuario extends Persona {

    public Usuario(String nombre, String correo, String usuario, String contraseña, String rol) {
        super(nombre, correo, usuario, contraseña, rol);
    }
    
}
